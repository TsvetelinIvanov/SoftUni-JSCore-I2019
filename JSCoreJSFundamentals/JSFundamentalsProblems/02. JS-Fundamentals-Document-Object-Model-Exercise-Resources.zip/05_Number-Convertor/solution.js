function solve() {
//TODO
}