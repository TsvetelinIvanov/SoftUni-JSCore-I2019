function solve() {
   //TODO
} 