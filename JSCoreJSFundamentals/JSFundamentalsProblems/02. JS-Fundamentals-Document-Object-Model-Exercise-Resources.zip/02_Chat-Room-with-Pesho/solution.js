function solve() {
 //TODO
}