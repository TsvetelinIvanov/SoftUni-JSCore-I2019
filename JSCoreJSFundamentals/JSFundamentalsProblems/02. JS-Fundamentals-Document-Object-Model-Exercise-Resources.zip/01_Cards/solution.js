function solve() {
    //TODO
}